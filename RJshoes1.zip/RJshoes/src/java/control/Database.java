package control;

import java.io.IOException;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author RAJA M
 */
@WebServlet(name = "Database", urlPatterns = {"/Database"})
public class Database extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
       
   /*     String readAll="select * from RAJA.REGISTRATION";
            Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/Mahesh","Raja","12345");
            System.out.println("connected using Login page");
            //String sql="select * from RAJA.REGISTRATION";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(readAll);
        
            out.println("hi");
            String uname=rs.getString(1);
                out.print("<html>");
                out.print("<body>");
                out.print("<table><tr><td>");
                out.print(uname);
                out.print("</td></tr></table>");
                out.print("</body>");
                out.print("</html>");
            
        */
    
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            
            String readAll="select * from RAJA.REGISTRATION";
            Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/Raja","Rja","12345");
            System.out.println("connected using Login page");
            //String sql="select * from RAJA.REGISTRATION";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(readAll);
            
                while(rs.next())
                {
                    String uname=rs.getString(1);
                    String email=rs.getString(2);
                    String npass=rs.getString(3);
                    String address=rs.getString(5);
                    String state=rs.getString(6);
                    String phone=rs.getString(7);
                    
                    System.out.println("Name            :"+uname);
                    System.out.println("Email           :"+email);
                    System.out.println("Password        :"+npass);
                    System.out.println("Address         :"+address);
                    System.out.println("State           :"+state);
                    System.out.println("Phone Number    :"+phone);
                    
                    System.out.println("------------------------------");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        }
    
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
